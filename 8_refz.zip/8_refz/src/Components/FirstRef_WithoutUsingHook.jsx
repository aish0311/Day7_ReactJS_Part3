import React from 'react';
import ReactDOM from 'react-dom';

// With out using Hooks - useRef().
class FirstRef extends React.Component {
  constructor(){
      super();
      this.state = { count: 0};
  }

  updateByUsingRefs(e){
     this.setState({ count: this.refs.counterRef.value});
  }

  render(){
   return (
    <div>
     Counts <input type="text" ref="counterRef" onChange = {this.updateByUsingRefs.bind(this)}/>
    <br/>
      <p>{this.state.count}</p>
   </div>
   );
  }
 }
  ReactDOM.render(<FirstRef/>, document.getElementById('root'));

  export default FirstRef
// There are 2 rules to remember about references:
// 1) The value of the reference is persisted (stays the same) between component re-renderings.
// 2) Updating a reference doesn't trigger a component re-rendering.