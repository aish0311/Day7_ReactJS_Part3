import './App.css';
import FirstRef from './Components/FirstRef_WithoutUsingHook';

function App() {
  return (
     <FirstRef/>

  );
}

export default App;
